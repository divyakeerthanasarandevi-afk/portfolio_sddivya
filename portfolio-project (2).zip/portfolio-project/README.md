# College Portfolio

A personal portfolio website (certificates, projects, internships, links).

## Files
- `index.html` - page structure
- `style.css` - light theme and layout
- `script.js` - tabs, editing, certificate full view, backup/restore
- `images/` - place for your photos

## Run
Open `index.html` in a browser. No install needed.

## Publish
Push these files to GitHub, then Settings -> Pages -> choose the main branch.
